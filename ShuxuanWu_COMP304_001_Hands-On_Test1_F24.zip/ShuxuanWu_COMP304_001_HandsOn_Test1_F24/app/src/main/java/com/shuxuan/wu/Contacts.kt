package com.shuxuan.wu

//Student ID: 301203269
//Student Name: Shuxuan Wu
// Data Class for Contact
data class Contact(
    val name: String,
    val phone: String,
    val email: String,
    val type: String
)
